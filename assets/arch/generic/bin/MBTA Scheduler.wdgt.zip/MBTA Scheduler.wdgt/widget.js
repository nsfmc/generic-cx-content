var gDoneButton;
var gInfoButton;

function storePrefs(){
  //store values globally
  direction = $('directionlist').value
  currentRoute = $('routelist').value
  currentStop = $('stoplist').value
  
  //store values 'permanently'
  if(window.widget){
    widget.setPreferenceForKey(85,"route")
    widget.setPreferenceForKey(currentStop,"stopname")
    widget.setPreferenceForKey(direction,"direction")
  }
}

function setDefaultPrefs(){
  currentRoute = 85
  currentStop = "Somerville Ave & Union Square"
  direction = "inbound"
}

function showPrefs(){  
  var front = document.getElementById("front");
  var back = document.getElementById("back");

  if (window.widget)
    widget.prepareForTransition("ToBack");

  front.style.display="none";
  back.style.display="block";

  

  if (window.widget)
    setTimeout ('widget.performTransition();', 0);
}

function hidePrefs(){
  var front = document.getElementById("front");
  var back = document.getElementById("back");
  
  storePrefs()
  
  initChrome()
  drawWidget()

  if (window.widget)
    widget.prepareForTransition("ToFront");

  back.style.display="none";
  front.style.display="block";

  if (window.widget)
    setTimeout ('widget.performTransition();', 0);
}

//pad single digit integers with zeros and return a string
function zpInt(n){
  if (n.toString().length == 1)
    return "0"+n.toString()
  return n.toString()
}

//ad an s to a word if the number warrants it
function addS(number, string){
  if (number != 1) {
    return number+" "+string+"s "
  } 
  return number+" "+string + " ";
}

//this takes the difference of two date objects and returns a string representation.
function niceDiff(ms){
  seconds = ms / 1000
  r_minutes = Math.floor(seconds / 60)
  r_hours = Math.floor(r_minutes / 60)
  r_seconds = Math.floor(seconds - (r_minutes * 60))
  if (r_hours > 1){
    return addS(r_hours,"hour")
  }else if(r_minutes > 2){
    return addS(r_minutes,"minute")
  }else if(r_minutes > 0){
    return addS(r_minutes,"minute") + addS(r_seconds,"second")
  }else{
    return addS(r_seconds,"second")
  }
}


/**
 * map is a javascript 1.6 array feature that needs to be added for 
 * safari despite being present in webkit.
 */
if (!Array.prototype.map){
  Array.prototype.map = function(fun /*, thisp*/){
    var len = this.length;
    if (typeof fun != "function")
      throw new TypeError();

    var res = new Array(len);
    var thisp = arguments[1];
    for (var i = 0; i < len; i++){
      if (i in this)
        res[i] = fun.call(thisp, this[i], i, this);
    }
    return res;
  };
}



