function setup(){
  //global apple buttons
  gDoneButton = new AppleGlassButton(document.getElementById("doneButton"), "Done", hidePrefs);
  gInfoButton = new AppleInfoButton(document.getElementById("infoButton"), document.getElementById("front"), "black", "black", showPrefs);
  
  //pull any saved values

  if(!getPrefs()){
    setDefaultPrefs()
    showPrefs()
  }
    
  //this should happen once a day or so or each time we draw the front
  initChrome()

  //this we should do each time we draw the widget
  drawWidget()
}

if(window.widget){
  widget.onshow = onshow;
  widget.onhide = onhide;
}

function onshow(){
  try{
    if(!timer){
      drawWidget()
      timer = setInterval("drawWidget()",25000)
    }
  }catch(e){
    drawWidget()
    timer = setInterval("drawWidget()",25000)
  }
}

function onhide(){
  if(timer){
    clearInterval(timer)
    timer=false
  }
}

function getPrefs(){
  //if in a widget environment, pull (global) values first
  if(window.widget){
    currentRoute = widget.preferenceForKey("route")
    currentStop = widget.preferenceForKey("stopname")
    direction = widget.preferenceForKey("direction")

    
  }else{ //don't know what to do if not a widget
  }
  try{
    // this statement will fail if values not set
    // so it's inside a try/catch loop
    if(currentRoute && currentStop && direction)
      return true
    return false    
  }catch(e){
    return false
  }
}

function initChrome(){
  //drawWidget()??
  $('route').innerHTML = currentRoute
  $('direction').innerHTML = direction
  $('stopname').innerHTML = currentStop

  //schedule, currentRoute and currentStop are global wide widget vars
  //we should only have to do this once a day
  var table = getCurrentTimetable(schedule,currentRoute,currentStop)
  makeDate = function(e){var d = new Date(); d.parseTime(e); return d}
  timetable = table.map(makeDate)  
  
  
  //setting values of prefs in chrome
  //$('inbound').checked = (direction == "inbound") ? true : false
  //$('outbound').checked = (direction == "outbound") ? true : false
  popSelectFirst('routelist',schedule)
  populateSelect('stoplist',direction,schedule[currentRoute])
  var opts = $('stoplist').getElementsByTagName('option')
  for(var i = 0; i < opts.length; i++){
    if(opts[i].value == currentStop)
      opts[i].selected = true
  }
}

function drawWidget(){
  //these should always be recalculated each time the widget is drawn
  //NOTE that timetable must be specified or this function will break  
  now = new Date();
  nextTime = binsearch(timetable,now)
  diff = nextTime - now

  if(!nextTime){
    $('info').innerHTML = "<h2>no busses running</h2>"
  }else{
    //these are pretty-printed versions of time values
    var ppHour = (nextTime.getHours() > 12) ? nextTime.getHours() % 12 : nextTime.getHours()
    var ppMin = zpInt(nextTime.getMinutes())
    var ppDiff = niceDiff(diff)

    $('time').innerHTML = ppHour + ":" + ppMin
    $('remaining').innerHTML = ppDiff
  }
}

var schedule = { 
  85 : {
    "weekday" :{
      "inbound" :{
        "timetable":{
          "Main St & Kendall Station":["6:15 AM","6:40 AM","7:14 AM","7:44 AM","8:19 AM","8:54 AM","9:32 AM","10:12 AM","10:52 AM","11:32 AM","12:17 PM","01:02 PM","01:42 PM","02:22 PM","03:02 PM","03:42 PM","04:23 PM","05:03 PM","05:43 PM","6:21 PM","7:01 PM"],
          "Somerville Ave & Union Square":["6:8 AM","6:33 AM","7:03 AM","7:33 AM","8:8 AM","8:43 AM","9:23 AM","10:03 AM","10:43 AM","11:23 AM","12:8 PM","12:53 PM","01:33 PM","02:13 PM","02:53 PM","03:33 PM","04:13 PM","04:53 PM","05:33 PM","6:13 PM","6:53 PM"],
          "Avon St & Central St":["6:05 AM","6:30 AM","7:00 AM","7:30 AM","8:05 AM","8:40 AM","9:20 AM","10:00 AM","10:40 AM","11:20 AM","12:05 PM","12:50 PM","01:30 PM","02:10 PM","02:50 PM","03:30 PM","04:10 PM","04:50 PM","05:30 PM","6:10 PM","6:50 PM"]
        },
        "stops":["Avon St & Central St","Somerville Ave & Union Square","Main St & Kendall Station"]
      },
      "outbound" : {
        "timetable":{
          "Main St & Kendall Station":["6:18 AM","6:45 AM","7:15 AM","7:50 AM","8:25 AM","9:00 AM","9:40 AM","10:20 AM","11:00 AM","11:40 AM","12:25 PM","01:10 PM","01:50 PM","02:30 PM","03:10 PM","03:50 PM","04:30 PM","05:10 PM","05:50 PM","6:30 PM","7:05 PM"],
          "Webster Ave & Prospect St":["6:25 AM","6:52 AM","7:23 AM","7:58 AM","8:33 AM","9:09 AM","9:49 AM","10:29 AM","11:9 AM","11:49 AM","12:34 PM","01:19 PM","01:59 PM","02:39 PM","03:19 PM","03:59 PM","04:40 PM","05:20 PM","6:00 PM","6:38 PM","7:13 PM"],
          "Avon St & Central St":["6:28 AM","6:55 AM","7:26 AM","8:01 AM","8:36 AM","9:12 AM","9:52 AM","10:32 AM","11:12 AM","11:52 AM","12:37 PM","01:22 PM","02:02 PM","02:42 PM","03:22 PM","04:02 PM","04:43 PM","05:23 PM","6:03 PM","6:41 PM","7:16 PM"]
        },
        "stops":["Main St & Kendall Station","Webster Ave & Prospect St","Avon St & Central St"]
      }
    }
  },
  88:{
    "weekday":{
      "inbound":{
        "timetable":{
          "Clarendon Hill Busway":["05:20 AM","05:40 AM","06:00 AM","06:20 AM","06:35 AM","06:45 AM","06:54 AM","07:05 AM","07:15 AM","07:25 AM","07:35 AM","07:45 AM","07:55 AM","08:05 AM","08:15 AM","08:30 AM","08:45 AM","09:05 AM","09:35 AM","10:05 AM","10:35 AM","11:05 AM","11:35 AM","12:05 PM","12:35 PM","01:05 PM","01:35 PM","02:00 PM","02:25 PM","02:50 PM","03:05 PM","03:20 PM","03:35 PM","03:50 PM","04:10 PM","04:25 PM","04:40 PM","04:55 PM","05:10 PM","05:25 PM","05:40 PM","05:55 PM","06:10 PM","06:25 PM","06:38 PM","07:10 PM","07:40 PM","08:10 PM","08:40 PM","09:10 PM","09:40 PM","10:10 PM","10:40 PM","11:10 PM","11:40 PM","12:10 AM"],
          "Holland St & Dover St":["05:23 AM","05:43 AM","06:03 AM","06:23 AM","06:38 AM","06:48 AM","06:57 AM","07:11 AM","07:21 AM","07:31 AM","07:41 AM","07:51 AM","08:01 AM","08:11 AM","08:21 AM","08:34 AM","08:49 AM","09:09 AM","09:39 AM","10:09 AM","10:39 AM","11:09 AM","11:39 AM","12:09 PM","12:39 PM","01:09 PM","01:39 PM","02:04 PM","02:29 PM","02:54 PM","03:09 PM","03:24 PM","03:39 PM","03:54 PM","04:14 PM","04:29 PM","04:44 PM","04:59 PM","05:14 PM","05:29 PM","05:44 PM","05:59 PM","06:14 PM","06:29 PM","06:42 PM","07:14 PM","07:44 PM","08:14 PM","08:44 PM","09:14 PM","09:44 PM","10:14 PM","10:44 PM","11:14 PM","11:44 PM","12:14 AM"],
          "Lechmere Station":["05:39 AM","05:59 AM","06:19 AM","06:39 AM","06:54 AM","07:08 AM","07:24 AM","07:39 AM","07:49 AM","07:59 AM","08:09 AM","08:19 AM","08:29 AM","08:37 AM","08:45 AM","08:56 AM","09:11 AM","09:31 AM","10:01 AM","10:31 AM","11:01 AM","11:31 AM","12:01 PM","12:31 PM","01:01 PM","01:31 PM","02:01 PM","02:26 PM","02:51 PM","03:16 PM","03:31 PM","03:46 PM","04:01 PM","04:16 PM","04:36 PM","04:51 PM","05:06 PM","05:21 PM","05:36 PM","05:51 PM","06:06 PM","06:21 PM","06:36 PM","06:51 PM","07:02 PM","07:29 PM","07:59 PM","08:29 PM","08:59 PM","09:29 PM","09:59 PM","10:29 PM","10:59 PM","11:29 PM","11:59 PM","12:29 AM"]
        },
        "stops":["Clarendon Hill Busway","Holland St & Dover St","Lechmere Station"]
      },
      "outbound":{
        "timetable":{
          "Clarendon Hill Busway":["05:57 AM","06:17 AM","06:37 AM","06:57 AM","07:16 AM","07:27 AM","07:37 AM","07:47 AM","08:02 AM","08:12 AM","08:27 AM","08:42 AM","08:57 AM","09:12 AM","09:27 AM","09:47 AM","10:17 AM","10:47 AM","11:17 AM","11:47 AM","12:17 PM","12:47 PM","01:17 PM","01:47 PM","02:19 PM","02:40 PM","03:00 PM","03:02 PM","03:07 PM","03:12 PM","03:15 PM","03:17 PM","03:30 PM","03:45 PM","04:05 PM","04:20 PM","04:35 PM","04:50 PM","05:05 PM","05:20 PM","05:35 PM","05:50 PM","06:05 PM","06:20 PM","06:35 PM","06:50 PM","07:05 PM","07:14 PM","07:38 PM","08:08 PM","08:38 PM","09:08 PM","09:38 PM","10:08 PM","10:38 PM","11:08 PM","11:38 PM","12:08 AM","12:38 AM"],
          "Davis Sqare Busway":["05:51 AM","06:11 AM","06:31 AM","06:51 AM","07:09 AM","07:20 AM","07:30 AM","07:40 AM","07:55 AM","08:05 AM","08:20 AM","08:35 AM","08:50 AM","09:05 AM","09:20 AM","09:40 AM","10:10 AM","10:40 AM","11:10 AM","11:40 AM","12:10 PM","12:40 PM","01:10 PM","01:40 PM","02:13 PM","02:34 PM","02:54 PM","02:55 PM","03:00 PM","03:05 PM","03:09 PM","03:10 PM","03:24 PM","03:39 PM","03:59 PM","04:14 PM","04:29 PM","04:44 PM","04:59 PM","05:14 PM","05:29 PM","05:44 PM","05:59 PM","06:14 PM","06:29 PM","06:44 PM","06:59 PM","07:08 PM","07:32 PM","08:02 PM","08:32 PM","09:02 PM","09:32 PM","10:02 PM","10:32 PM","11:02 PM","11:32 PM","12:02 AM","12:32 AM"],
          "Lechmere Station":["05:40 AM","06:00 AM","06:20 AM","06:40 AM","06:55 AM","07:05 AM","07:15 AM","07:25 AM","07:40 AM","07:50 AM","08:05 AM","08:20 AM","08:35 AM","08:50 AM","09:05 AM","09:25 AM","09:55 AM","10:25 AM","10:55 AM","11:25 AM","11:55 AM","12:25 PM","12:55 PM","01:25 PM","01:55 PM","02:15 PM","02:35 PM","02:50 PM","03:05 PM","03:20 PM","03:40 PM","03:55 PM","04:10 PM","04:25 PM","04:40 PM","04:55 PM","05:10 PM","05:25 PM","05:40 PM","05:55 PM","06:10 PM","06:25 PM","06:40 PM","06:55 PM","07:20 PM","07:50 PM","08:20 PM","08:50 PM","09:20 PM","09:50 PM","10:20 PM","10:50 PM","11:20 PM","11:50 PM","12:20 AM"],
          "Highland Ave & School St":["02:35 PM","02:40 PM","02:45 PM","02:50 PM"]
        },
        "stops":["Highland Ave & School St","Lechmere Station","Davis Sqare Busway","Clarendon Hill Busway"]
      }
    }
  }
}

/**
 *  binsearch takes an array and an item (that must be comparable with </>)
 *  and returns the next biggest item than item. This assumes that array is
 *  sorted, but it usually is anyway.
 */
function binsearch(array,item){
  var l = -1; var r = array.length; //bounds outside search area
  var mid = (l + r) >>> 1;
  while((r - l) > 2){
    if(item >= array[mid]){
      l=mid;
    }
    else{
      r=mid+1;
    }
    mid=(l+r) >>> 1;
  }
  return (item > array[mid]) ? false : array[mid]
}

/**
 * parseTime takes a written time, i.e. 3:42pm and applies it to a date object
 */
Date.prototype.parseTime = function(time){
  //12PM == 1200
  //12AM == 0000

  var hmsRe = /([\d]{1}(?=\D*\d\d(\D+ | \b))|[\d]{2})/g
  var timeRe = /(\d{1,2})/g
  var modRe = /[A-Za-z]+/g

  var timeArr = time.match(timeRe)
  var mod = time.match(modRe)[0].toLowerCase()[0]
  var ih = parseInt(timeArr[0])
  
  //this used to do some conditional magic for 24hr times, but not now
  var h = (mod == "a") ?  ih % 12 : ih % 12 + 12
  
  this.setHours(h);
  this.setMinutes(timeArr[1])
  this.setSeconds(0)
}

function getRoute(schedule, route){return schedule[route]}
function getToday(routeSchedule){return routeSchedule["weekday"]}
function getInbound(todaySchedule){return todaySchedule["inbound"]}
function getOutbound(todaySchedule){return todaySchedule["outbound"]}
function getTimetable(detailedSchedule){return detailedSchedule["timetable"]}
function getStopTimes(timetable,stopname){return timetable[stopname]}

function getCurrentTimetable(/* jsObject */ schedule,
                             /* int or string */ routeno,
                             /* string */stopname){
  
  var tt = schedule[routeno]["weekday"]["inbound"]["timetable"][stopname]
  return tt
}


function makeOption(str){
  var opt = document.createElement("option"); 
  opt.innerHTML = str
  return opt
}

function populateSelect(selectid/*,direction,array*/){
  
  var routeroute = $('routelist').value; var direction = $('directionlist').value;
  
  var arr = schedule[routeroute]["weekday"][direction]["stops"]
  
  if(window.widget){
    widget.setPreferenceForKey(direction,"direction");
    widget.setPreferenceForKey(arr[0],"stopname");
  }
  
  var select = document.getElementById(selectid)
  select.innerHTML = ""
  for(var i = 0; i < arr.length; i++){
    var opt = makeOption(arr[i])
    select.appendChild(opt)
  }
  
}

function popSelectFirst(selectid,obj){
  var select = document.getElementById(selectid)
  select.innerHTML = ""

  for(r in obj){
    var opt = makeOption(r)
    select.appendChild(opt)
  }
  select.firstChild.selected = true
}

function setStop(stopname){
  
}